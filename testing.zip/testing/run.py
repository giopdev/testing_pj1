import re

# Define token patterns in order.
# Note: The order matters for tie-breaking (earlier token wins if match lengths are equal).
token_patterns = [
    ("R0", re.compile(r"[1-9]")),
    ("R1", re.compile(r"[0-9]")),
    ("R2", re.compile(r"(?:[01])*[1-9][01]")),
    ("R3", re.compile(r"00(?:[1-9])*(?:[01])*")),
    ("R4", re.compile(
        r"(?:(?:00(?:[1-9])*(?:[01])*)*(?:(?:[01])*[1-9][01])*)000"))
]


def getToken(s, pos):
    """
    Try to match each token pattern at position 'pos' in the string s.
    Returns a tuple ((token_type, lexeme), new_position) using maximal munch.
    """
    best_match = None
    best_token = None

    # Check every token pattern
    for token_name, pattern in token_patterns:
        m = pattern.match(s, pos)
        if m:
            lexeme = m.group(0)
            # Choose the match with the longest lexeme.
            if best_match is None or len(lexeme) > len(best_match):
                best_match = lexeme
                best_token = token_name

    # If no pattern matched, we have a lexical error.
    if best_match is None:
        return None, pos
    return (best_token, best_match), pos + len(best_match)


def tokenize(s):
    """
    Tokenizes the entire string 's' (with whitespace already removed)
    by repeatedly calling getToken.
    """
    tokens = []
    pos = 0
    while pos < len(s):
        token, pos = getToken(s, pos)
        if token is None:
            raise ValueError("Lexical error at position {}".format(pos))
        tokens.append(token)
    return tokens


def main():
    # Given input string with whitespace ignored
    input_str = "99001101678100010101030123457000010"
    tokens = tokenize(input_str)

    # Print each token as a pair (token_type, lexeme)
    for token in tokens:
        print(token)


if __name__ == '__main__':
    main()
